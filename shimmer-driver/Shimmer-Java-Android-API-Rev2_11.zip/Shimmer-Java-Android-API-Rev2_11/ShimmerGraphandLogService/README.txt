25 May 2015
- Please note that this example only provides limited support for ExG (EMG/ECG) we recommend taking a look at multishimmertemplate for a more comprehensive example

- Connects a single Shimmer unit and displays uncalibrated data on the graph, and calibrated data in the text view.
- The graph and text display of sensor values is subSampled to prevent lag on lower end Android devices (see variable maxNumberofSamplesPerSecond in ShimmerGraph.java)

30 Sept 2013
- Pressure Sensor Currently Not supported
