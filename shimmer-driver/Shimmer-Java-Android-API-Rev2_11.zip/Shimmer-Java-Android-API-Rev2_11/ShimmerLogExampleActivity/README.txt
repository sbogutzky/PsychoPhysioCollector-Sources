25 May 2015
-Logs time stamp and accelerometer data unto the sd card of the Android device, note this is not the SD card of the Shimmer device
-If the log file does not show unmount and mount the sd card, this is due to the filesystem not refreshing itself on the Android device, when connected to the PC, post logging, this causes the file not to be seen
