- When Using Shimmer 3, ensure your gyroscope has been calibrated for the default range of 500dps using the SHimmer 9DoF Calibration Application

Changes Since Shimmer.java Rev 1.3
- Updated to set to default magrange for shimmer2 which is 0 and 1 for Shimmer3
- Removed unnecessary and cleaned up code
- Also fixed the gyro on the fly checkbox 
 