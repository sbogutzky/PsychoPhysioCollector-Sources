/** Automatically generated file. DO NOT MODIFY */
package com.example.shimmeradvancedexgexample;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}