Connects a single Shimmer unit calibrated accelerometer data can be seen on the console using the ShimmerTCPReceiver example.

1) First run the receiver (ShimmerTCPReceiver), and then run ShimmerTCPExample, note you will have to set the IPAddress and the Shimmer BT Address in the Android example