25 May 2015
-Demonstrates how to receive serialized objectclusters
-Example is to be used with ShimmerTCPExample of ShimmerPCTCPExample