25 May 2015

This example is to be used with ShimmerTECPReceiver, it demonstrates how to use the serialize method to transmit objectclusters via tcpip