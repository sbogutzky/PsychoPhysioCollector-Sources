Java Shimmer Connect
March 2014
Connects a single Shimmer, plots raw or calibrated data and logs data. 
	- Uses ShimmerPCInstrument Driver - implements driver's call back method
	- Fails to connect to Shimmer if not properly disconnected the previous time. Need to restart app in this case
	