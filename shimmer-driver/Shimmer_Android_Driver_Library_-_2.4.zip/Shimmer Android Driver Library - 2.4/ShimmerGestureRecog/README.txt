-In this gesture recognition application uses the Gyroscope to monitor hand movements and Dynamic Time Warping to detect gestures
-All three recordings need to be done for the application to work, any recordings left empty will cause a null pointer to occur
-A video showing its usage can be found on our youtube channel 

30 Sept 2013 
- Moved to legacy folder, not tested for used with Shimmer 3