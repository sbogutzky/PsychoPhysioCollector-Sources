Connects a single Shimmer unit calibrated accelerometer data can be seen on the LogCat and over TCP IP using one of the examples in the ShimmerTCPReceiver folder.

1) First run the receiver, and then run ShimmerTCPExample