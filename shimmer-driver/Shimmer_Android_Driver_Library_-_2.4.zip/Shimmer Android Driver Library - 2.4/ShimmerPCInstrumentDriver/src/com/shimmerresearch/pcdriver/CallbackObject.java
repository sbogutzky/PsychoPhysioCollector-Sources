//Object for callback method. Two components: an indicator(shows the type of notification message or the state) and the bluetooth address

package com.shimmerresearch.pcdriver;

public class CallbackObject {
	public int mIndicator;
	public String bluetoothAddress;
	
	public CallbackObject(int ind, String myBlueAdd){
		mIndicator = ind;
		bluetoothAddress = myBlueAdd;
	}
	
}
