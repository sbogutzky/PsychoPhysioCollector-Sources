30 Sept 2013

- Updated code to only send commands after the MSG_STATE_FULLY_INITIALIZED message is received