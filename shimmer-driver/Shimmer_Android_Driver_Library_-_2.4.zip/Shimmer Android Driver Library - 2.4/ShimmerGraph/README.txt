THIS IS NOW CONSIDERED A LEGACY EXAMPLE

- Connects a single Shimmer unit and displays uncalibrated data on the graph, and calibrated data in the text view.
- The graph and text display of sensor values is subSampled to prevent lag on lower end Android devices (see variable maxNumberofSamplesPerSecond in ShimmerGraph.java)

30 Sept 2013
- Moved to legacy folder, works with Shimmer3, however the graph range has not been updated for certain Shimmer3 Sensors