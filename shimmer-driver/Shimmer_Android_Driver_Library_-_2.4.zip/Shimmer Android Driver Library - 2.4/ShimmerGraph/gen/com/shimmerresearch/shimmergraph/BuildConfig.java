/** Automatically generated file. DO NOT MODIFY */
package com.shimmerresearch.shimmergraph;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}