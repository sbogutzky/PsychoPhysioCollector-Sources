/** Automatically generated file. DO NOT MODIFY */
package com.shimmerresearch.multishimmertemplate;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}