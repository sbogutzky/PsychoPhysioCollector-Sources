UNSUPPORTED EXAMPLE

As this is not a finished application, to avoid facing problems take note of the following:-

MultiShimmerPlay while not completed it is a good example on how to connect multiple shimmer devices to an Android device.

In regards to data plotting
	- After selecting view grapg, do a long click on the middle of screen to view the graph options, pick the sensor you want to view from the options
	- Also note that the scale of the graph  has not been optimized

In regards to using the sound play option (see demonstration http://www.youtube.com/watch?v=uH7HQ1_SFWk), use the following instructions
	-Once you have connected all the devices and assigned all the sounds, select All Devices and enable only the gyroscope sensor, next while All Devices is selected press the start streaming command.
	-Note that different Sampling rates may change the sensitivity of the Trigger.	
	-While streaming you will still be able to configure the sounds by exiting the All Devices menu, and picking the device you want from the main menu.

In regards to sending commands, ensure the Shimmer device is not streaming data

xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
30 Sept 2013

- Moved to legacy folder, with the introduction of the MultiShimmerTemplate
- Supports Shimmer 3, but the list of enabled sensors has not been updated in terms of the interface, hence not all Shimmer sensors are supported.