- Connects a single Shimmer unit and displays uncalibrated data on the graph, and calibrated data in the text view.
- The graph and text display of sensor values is subSampled to prevent lag on lower end Android devices (see variable maxNumberofSamplesPerSecond in ShimmerGraph.java)

30 Sept 2013
- Pressure Sensor Currently Not supported
