THIS IS NOW CONSIDERED A LEGACY EXAMPLE

Description

Connects a two Shimmer units and displays uncalibrated data on the graph, and calibrated data in the text view.

30 Sept 2013

- Moved to legacy folder, users should note that for Shimmer 3 the graph has not been adjusted, data for certain sensors will not appear on the graph
- Users are encouraged to check out the example MultiShimmerTemplate